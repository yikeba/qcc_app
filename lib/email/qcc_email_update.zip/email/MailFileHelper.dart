import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

import 'MailMimeBuilder.dart';

/// 附件选取 / 保存。依赖 file_picker（^13.x，API：静态方法 + PlatformFile.readAsBytes）。
///
/// macOS 沙盒需在 Runner/*.entitlements 加：
///   com.apple.security.files.user-selected.read-write = true
class MailFileHelper {
  /// 单封邮件附件总量上限（与常见邮件服务一致，base64 后约 33MB）
  static const int maxTotalBytes = 25 * 1024 * 1024;

  /// 选择多个文件作为附件；用户取消返回空列表
  static Future<List<OutgoingAttachment>> pickAttachments() async {
    final files = await FilePicker.pickFiles(dialogTitle: '选择附件');
    final out = <OutgoingAttachment>[];
    for (final f in files) {
      final bytes = await f.readAsBytes();
      out.add(OutgoingAttachment(
        filename: f.name,
        mimeType: OutgoingAttachment.guessMime(f.name),
        bytes: bytes,
      ));
    }
    return out;
  }

  /// 弹出系统"另存为"保存附件；返回保存位置（取消为 null）
  static Future<Uri?> saveAttachment({
    required String filename,
    required Uint8List bytes,
    String mimeType = 'application/octet-stream',
  }) =>
      FilePicker.saveFile(
        fileName: filename,
        bytes: bytes,
        mimeType: mimeType,
        dialogTitle: '保存附件',
      );

  static String humanSize(int n) {
    if (n < 1024) return '$n B';
    if (n < 1024 * 1024) return '${(n / 1024).toStringAsFixed(1)} KB';
    return '${(n / 1024 / 1024).toStringAsFixed(1)} MB';
  }
}
